import json
from jsonschema import validate
from jsonschema.exceptions import ValidationError
import apache_beam as beam
from apache_beam.options.pipeline_options import PipelineOptions


def run():
    # Beam pipeline options
    options = PipelineOptions(save_main_session=True, streaming=True)

    # Schema for BigQuery table
    # table_schema = {
    #     "fields": [
    #         {"name": "pickup_datetime",
    #          "type": "DATETIME"},
    #         {"name": "dropoff_datetime",
    #          "type": "DATETIME"},
    #         {"name": "passenger_count",
    #          "type": "INTEGER"},
    #         {"name": "trip_distance",
    #          "type": "FLOAT"},
    #         {"name": "pickup_longitude",
    #          "type": "STRING"},
    #         {"name": "pickup_latitude",
    #          "type": "STRING"},
    #         {"name": "dropoff_longitude",
    #          "type": "STRING"},
    #         {"name": "dropoff_latitude",
    #          "type": "STRING"},
    #         {"name": "payment_type",
    #          "type": "STRING"},
    #         {"name": "fair_amount",
    #          "type": "FLOAT"},
    #         {"name": "extra",
    #          "type": "FLOAT"},
    #         {"name": "mta_tax",
    #          "type": "FLOAT"},
    #         {"name": "tip_amount",
    #          "type": "FLOAT"},
    #         {"name": "tolls_amount",
    #          "type": "FLOAT"},
    #         {"name": "total_amount",
    #          "type": "FLOAT"}
    #     ]
    # }

    raw_table_schema = {
        "fields": [
            {"name": "ride_id",
             "type": "STRING"},
            {"name": "point_idx",
             "type": "INTEGER"},
            {"name": "latitude",
             "type": "FLOAT"},
            {"name": "longitude",
             "type": "FLOAT"},
            {"name": "timestamp",
             "type": "STRING"},
            {"name": "meter_reading",
             "type": "FLOAT"},
            {"name": "meter_increment",
             "type": "FLOAT"},
            {"name": "ride_status",
             "type": "STRING"},
            {"name": "passenger_count",
             "type": "INTEGER"}
        ]
    }

    # JSON Schema
    json_schema = {
        "type": "object",
        "properties": {
            "ride_id": {"type": "string"},
            "point_idx": {"type": "number"},
            "latitude": {"type": "number"},
            "longitude": {"type": "number"},
            "timestamp": {"type": "string"},
            "meter_reading": {"type": "number"},
            "meter_increment": {"type": "number"},
            "ride_status": {"type": "string"},
            "passenger_count": {"type": "number"}

        }
    }

    # Static input and output locations
    input_topic = "projects/eliiza-de-student-project-2022/topics/taxi-data"
    output_table_name = "eliiza-de-student-project-2022:testing.realtime_test"
    error_table_name = "eliiza-de-student-project-2022:testing.error_test"

    # Steps carried out in pipeline
    # 1. Read input from Pub/Sub topic
    # 2. Parse JSON
    # 3. Write output to BigQuery table

    def parse_json(element):
        row = json.loads(element.decode('utf-8'))
        return row

    def get_error(row):
        try:
            validate(instance=row, schema=json_schema)
        except ValidationError:
            return row
        else:
            pass

    def get_valid_row(row):
        try:
            validate(instance=row, schema=json_schema)
        except ValidationError:
            pass
        else:
            return row

    # Creating the pipeline
    pipeline = beam.Pipeline(options=options)

    input_collection = (
        pipeline
        | 'ReadFromPubSubTopic' >> beam.io.ReadFromPubSub(input_topic)
        | 'ParseJSONInput' >> beam.Map(parse_json)
    )

    # Branching out the pipeline to filter out errors and putting them in a new table
    (
        input_collection
        | 'RetrieveError' >> beam.Map(get_error)
        | 'WriteToErrorTable' >> beam.io.WriteToBigQuery(
            error_table_name,
            schema=raw_table_schema,
            create_disposition=beam.io.BigQueryDisposition.CREATE_IF_NEEDED,
            write_disposition=beam.io.BigQueryDisposition.WRITE_APPEND
        )
    )

    # Branching the pipeline to add valid
    (
        input_collection
        | 'RetrieveValidRows' >> beam.Map(get_valid_row)
        | 'WriteToOutputTable' >> beam.io.WriteToBigQuery(
            output_table_name,
            schema=raw_table_schema,
            create_disposition=beam.io.BigQueryDisposition.CREATE_IF_NEEDED,
            write_disposition=beam.io.BigQueryDisposition.WRITE_APPEND
        )
    )

    pipeline.run().wait_until_finish()


if __name__ == "__main__":
    run()
