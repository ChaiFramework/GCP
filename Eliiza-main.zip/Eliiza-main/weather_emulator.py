from google.cloud import pubsub_v1, storage
from dateutil.parser import parse, ParserError
from time import sleep
import json
import pickle
import numpy as np
from sklearn.ensemble import RandomForestRegressor
import pandas as pd
import warnings

warnings.filterwarnings("ignore")


def setValues(line, result):
    timestamp, temp, feels_like, dew, humidity, precip, precip_prob, snow_depth, windspeed, cloud_cover, visibility, conditions = line

    result["timestamp"] = timestamp
    result["temp"] = temp
    result["feels_like"] = feels_like
    result["dew"] = dew
    result["humidity"] = humidity
    result["precip"] = precip
    result["precip_prob"] = precip_prob
    result["snow_depth"] = snow_depth
    result["windspeed"] = windspeed
    result["cloud_cover"] = cloud_cover
    result["visibility"] = visibility
    result["conditions"] = conditions

    return result


def mapDateTime(df):
    dates_mapping = {'2022-01-01': 0,
                     '2022-01-02': 1,
                     '2022-01-03': 2,
                     '2022-01-04': 3,
                     '2022-01-05': 4,
                     '2022-01-06': 5,
                     '2022-01-07': 6,
                     '2022-01-08': 7,
                     '2022-01-09': 8,
                     '2022-01-10': 9,
                     '2022-01-11': 10,
                     '2022-01-12': 11,
                     '2022-01-13': 12,
                     '2022-01-14': 13,
                     '2022-01-15': 14,
                     '2022-01-16': 15,
                     '2022-01-17': 16,
                     '2022-01-18': 17,
                     '2022-01-19': 18,
                     '2022-01-20': 19,
                     '2022-01-21': 20,
                     '2022-01-22': 21,
                     '2022-01-23': 22,
                     '2022-01-24': 23,
                     '2022-01-25': 24,
                     '2022-01-26': 25,
                     '2022-01-27': 26,
                     '2022-01-28': 27,
                     '2022-01-29': 28,
                     '2022-01-30': 29,
                     '2022-01-31': 30,
                     '2022-02-01': 31,
                     '2022-02-02': 32,
                     '2022-02-03': 33,
                     '2022-02-04': 34,
                     '2022-02-05': 35,
                     '2022-02-06': 36,
                     '2022-02-07': 37,
                     '2022-02-08': 38,
                     '2022-02-09': 39,
                     '2022-02-10': 40,
                     '2022-02-11': 41,
                     '2022-02-12': 42,
                     '2022-02-13': 43,
                     '2022-02-14': 44,
                     '2022-02-15': 45,
                     '2022-02-16': 46,
                     '2022-02-17': 47,
                     '2022-02-18': 48,
                     '2022-02-19': 49,
                     '2022-02-20': 50,
                     '2022-02-21': 51,
                     '2022-02-22': 52,
                     '2022-02-23': 53,
                     '2022-02-24': 54,
                     '2022-02-25': 55,
                     '2022-02-26': 56,
                     '2022-02-27': 57,
                     '2022-02-28': 58,
                     '2022-03-01': 59,
                     '2022-03-02': 60,
                     '2022-03-03': 61,
                     '2022-03-04': 62,
                     '2022-03-05': 63,
                     '2022-03-06': 64,
                     '2022-03-07': 65,
                     '2022-03-08': 66,
                     '2022-03-09': 67,
                     '2022-03-10': 68,
                     '2022-03-11': 69,
                     '2022-03-12': 70,
                     '2022-03-13': 71,
                     '2022-03-14': 72,
                     '2022-03-15': 73,
                     '2022-03-16': 74,
                     '2022-03-17': 75,
                     '2022-03-18': 76,
                     '2022-03-19': 77,
                     '2022-03-20': 78,
                     '2022-03-21': 79,
                     '2022-03-22': 80,
                     '2022-03-23': 81,
                     '2022-03-24': 82,
                     '2022-03-25': 83,
                     '2022-03-26': 84,
                     '2022-03-27': 85,
                     '2022-03-28': 86,
                     '2022-03-29': 87,
                     '2022-03-30': 88,
                     '2022-03-31': 89,
                     '2022-04-01': 90,
                     '2022-04-02': 91,
                     '2022-04-03': 92,
                     '2022-04-04': 93,
                     '2022-04-05': 94,
                     '2022-04-06': 95,
                     '2022-04-07': 96,
                     '2022-04-08': 97,
                     '2022-04-09': 98,
                     '2022-04-10': 99,
                     '2022-04-11': 100,
                     '2022-04-12': 101,
                     '2022-04-13': 102,
                     '2022-04-14': 103,
                     '2022-04-15': 104,
                     '2022-04-16': 105,
                     '2022-04-17': 106,
                     '2022-04-18': 107,
                     '2022-04-19': 108,
                     '2022-04-20': 109,
                     '2022-04-21': 110,
                     '2022-04-22': 111,
                     '2022-04-23': 112,
                     '2022-04-24': 113,
                     '2022-04-25': 114,
                     '2022-04-26': 115,
                     '2022-04-27': 116,
                     '2022-04-28': 117,
                     '2022-04-29': 118,
                     '2022-04-30': 119,
                     '2022-05-01': 120,
                     '2022-05-02': 121,
                     '2022-05-03': 122,
                     '2022-05-04': 123,
                     '2022-05-05': 124,
                     '2022-05-06': 125,
                     '2022-05-07': 126,
                     '2022-05-08': 127,
                     '2022-05-09': 128,
                     '2022-05-10': 129,
                     '2022-05-11': 130,
                     '2022-05-12': 131,
                     '2022-05-13': 132,
                     '2022-05-14': 133,
                     '2022-05-15': 134,
                     '2022-05-16': 135,
                     '2022-05-17': 136,
                     '2022-05-18': 137,
                     '2022-05-19': 138,
                     '2022-05-20': 139,
                     '2022-05-21': 140,
                     '2022-05-22': 141,
                     '2022-05-23': 142,
                     '2022-05-24': 143,
                     '2022-05-25': 144,
                     '2022-05-26': 145,
                     '2022-05-27': 146,
                     '2022-05-28': 147,
                     '2022-05-29': 148,
                     '2022-05-30': 149,
                     '2022-05-31': 150,
                     '2022-06-01': 151,
                     '2022-06-02': 152,
                     '2022-06-03': 153,
                     '2022-06-04': 154,
                     '2022-06-05': 155,
                     '2022-06-06': 156,
                     '2022-06-07': 157,
                     '2022-06-08': 158,
                     '2022-06-09': 159,
                     '2022-06-10': 160,
                     '2022-06-11': 161,
                     '2022-06-12': 162,
                     '2022-06-13': 163,
                     '2022-06-14': 164,
                     '2022-06-15': 165,
                     '2022-06-16': 166,
                     '2022-06-17': 167,
                     '2022-06-18': 168,
                     '2022-06-19': 169,
                     '2022-06-20': 170,
                     '2022-06-21': 171,
                     '2022-06-22': 172,
                     '2022-06-23': 173,
                     '2022-06-24': 174,
                     '2022-06-25': 175,
                     '2022-06-26': 176,
                     '2022-06-27': 177,
                     '2022-06-28': 178,
                     '2022-06-29': 179,
                     '2022-06-30': 180}

    times_mapping = {'00:00:00': 0,
                     '01:00:00': 1,
                     '02:00:00': 2,
                     '03:00:00': 3,
                     '04:00:00': 4,
                     '05:00:00': 5,
                     '06:00:00': 6,
                     '07:00:00': 7,
                     '08:00:00': 8,
                     '09:00:00': 9,
                     '10:00:00': 10,
                     '11:00:00': 11,
                     '12:00:00': 12,
                     '13:00:00': 13,
                     '14:00:00': 14,
                     '15:00:00': 15,
                     '16:00:00': 16,
                     '17:00:00': 17,
                     '18:00:00': 18,
                     '19:00:00': 19,
                     '20:00:00': 20,
                     '21:00:00': 21,
                     '22:00:00': 22,
                     '23:00:00': 23}

    df["date"] = df["date"].replace(dates_mapping)
    df["time"] = df["time"].replace(times_mapping)

    return df


def mapCondition(df):
    conditions_mapping = {'Clear': [1, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                          'Overcast': [0, 1, 0, 0, 0, 0, 0, 0, 0, 0],
                          'Partially cloudy': [0, 0, 1, 0, 0, 0, 0, 0, 0, 0],
                          'Rain|Overcast': [0, 0, 0, 1, 0, 0, 0, 0, 0, 0],
                          'Rain|Partially cloudy': [0, 0, 0, 0, 1, 0, 0, 0, 0, 0],
                          'Snow': [0, 0, 0, 0, 0, 1, 0, 0, 0, 0],
                          'Snow|Overcast': [0, 0, 0, 0, 0, 0, 1, 0, 0, 0],
                          'Snow|Partially cloudy': [0, 0, 0, 0, 0, 0, 0, 1, 0, 0],
                          'Snow|Rain|Overcast': [0, 0, 0, 0, 0, 0, 0, 0, 1, 0],
                          'Snow|Rain|Partially cloudy': [0, 0, 0, 0, 0, 0, 0, 0, 0, 1]}

    condition = df.loc[0, "conditions"]
    conditions = list(conditions_mapping.keys())
    df[conditions] = conditions_mapping[condition]
    df.drop(columns=["conditions"], inplace=True)

    return df


def processData(json_result):
    # encoded_json = json_result.encode("utf-8")

    decoded_json = json.loads(json_result.decode("utf-8"))

    columns = list(decoded_json.keys())
    values = list(decoded_json.values())

    df = pd.DataFrame(columns=columns)
    df.loc[0] = values

    date, time = df.loc[0, "timestamp"].split("T")
    df["date"] = date
    df["time"] = time

    column = [
        'timestamp',
        'date',
        'time',
        'temp',
        'feels_like',
        'dew',
        'humidity',
        'precip',
        'precip_prob',
        'snow_depth',
        'windspeed',
        'cloud_cover',
        'visibility',
        'conditions',
    ]

    df = df[column]
    df.drop(columns=["timestamp"], inplace=True)

    # Integer encoding the "date" and "time" columns
    df = mapDateTime(df)

    # One-hot-encoding the "conditions" column
    df = mapCondition(df)

    return np.array(df.loc[0])


def getPrediction(values):
    model_file = "rf_model.sav"
    model = pickle.load(open(model_file, 'rb'))

    prediction = model.predict(values.reshape(1, -1))[0]

    return int(prediction)


def run(bucketName, fileName):
    # Project ID and Topic ID to publish messages to
    project_id = 'eliiza-de-student-project-2022'
    topic_id = "weather-data"

    # Publisher to publish messages to topic
    publisher = pubsub_v1.PublisherClient()
    topic_path = publisher.topic_path(project_id, topic_id)

    # Storage bucket containing the file to read
    storage_client = storage.Client()
    bucket = storage_client.bucket(bucketName)
    blob = bucket.blob(fileName)

    file = blob.download_as_text()

    file = file.split("\n")

    firstline = True
    timestamp = None

    for line in file:
        line = line.strip().split(",")
        if firstline is True:
            timestamp = line[0]

            # Convert csv columns to key value pair
            result = setValues(line, {})

            # Convert dict to json as message format
            json_result = json.dumps(result).encode("utf-8")
            firstline = False
            # print('%s' % (json_result))
            data = processData(json_result)
            pred = getPrediction(data)
            print(pred)
            # publisher.publish(topic_path, json_result.encode("utf-8"))
        else:
            try:
                d1 = parse(timestamp)
                d2 = parse(line[0])

            except ParserError:
                break
            else:
                diff = ((d2 - d1).total_seconds())/3500
                sleep(diff)
                timestamp = line[0]
                result = setValues(line, {})
                json_result = json.dumps(result).encode("utf-8")

                # print('%s' % (json_result))
                data = processData(json_result)
                pred = getPrediction(data)
                print(pred)
            # publisher.publish(topic_path, json_result.encode("utf-8"))

    print("Finished publishing all messages")


if __name__ == "__main__":
    run("nyc_weather_data_2022", "nyc_weather_2022_v3.csv")
