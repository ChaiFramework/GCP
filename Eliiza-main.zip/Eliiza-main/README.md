# Data Science Postgraduate Project - Eliiza
## Team Members
1. Jason Yong - S3555422
2. Arjun Padmanabha Pillai - S3887231
3. Sai Vamsi Chunduru - S3884753

## Dependencies For Apache Beam Pipeline Code
In order to execute the pipeline code locally or using Dataflow, the following dependencies will need to be installed.

1. Install the Python packaging standard: `pip install wheel`
2. Install the latest version of the Apache Beam SDK for Python: `pip install 'apache-beam[gcp]'`
3. Ensure that the service account credentials JSON for the project are in the `credentials` folder of the project to allow the pipeline to access the GCP services.
4. Replace the `GOOGLE_APPLICATION_CREDENTIALS` variable with the path to the credentials JSON file. e.g. `GOOGLE_APPLICATION_CREDENTIALS="<path_to_json>"`
5. Create a Cloud Storage Bucket on GCS which will be used as the staging and temp location for the Apache Beam pipeline. 
6. Take the name of the Cloud Storage Bucket and set it as the `BUCKET` variable in the `.env` file. e.g. `BUCKET="gs://<bucket_name>"`
7. Prior to executing the pipeline, in the terminal in the project folder, enter `source .env` in order to set all the environment variables required for executing the pipeline. Check the `.env` file for see what variables are needed.


## Commit History:
Each entry in the commit history follows the following format: <br> 
<br>
<b>Header: Corresponding Task On Jira</b>
- <b>Description</b>: A short descreption of the commit <br>
- <b>File name</b>: The name of the file <br>
- <b>Location</b>: The location of the file in the repository <br>
- <b>Requirements</b>: How to execute the file (if applicable) 
<br>

#### EL-20 Apache Beam Pipeline Prototype: Write to BigQuery [Jason]
<b>Description</b>: The pipeline is able to write data to the BigQuery table <br>
<b>File name</b>: `pipeline.py` <br>
<b>Location</b>: https://github.com/arjunS3887231/Eliiza/blob/main/pipeline.py <br>
<b>Requirements</b>: In the terminal run:
`python3 pipeline.py \
--project=${PROJECT_ID} \
--region=${REGION} \
--runner=${RUNNER} \
--staging_location=${PIPELINE_FOLDER}/staging \
--temp_location=${PIPLINE_FOLDER}/temp` <br>
<br>

#### EL-22 NYC Historic Weather Data [Jason]
<b>Description</b>: Historic 2015 Weather data made to look like 2022 <br>
<b>File name</b>: `nyc_weather_2022_v3.csv` <br>
<b>Location</b>: https://github.com/arjunS3887231/Eliiza/blob/main/nyc_weather_2022_v3.csv <br>
<b>Requirements</b>: N/A <br>
<br>

#### EL-31 GCP Certification: Google Cloud Big Data and Machine Learning Fundamentals [Jason]
<b>Description</b>: Completion badge for the Google Cloud Big Data and Machine Leraning Fundamentals course <br>
<b>File name</b>: `Big Data and Machine Learning Fundamentals.png` <br>
<b>Location</b>: https://github.com/arjunS3887231/Eliiza/blob/main/Data%20Engineering%20Course/Jason/Big%20Data%20and%20Machine%20Learning%20Fundamentals.png <br>
<b>Requirements</b>: N/A <br>
<br>

#### EL-33 Apache Beam Pipeline Prototype: Read From Pub/Sub [Jason]
<b>Description</b>: The pipeline is able to pull messages from the NYC Pub/Sub topic <br>
<b>File name</b>: `pipeline.py` <br>
<b>Location</b>: https://github.com/arjunS3887231/Eliiza/blob/main/pipeline.py <br>
<b>Requirements</b>: In the terminal run: `python3 pipeline.py` <br>
<br>

#### EL-34 Model Architecture [Jason]
<b>Description</b>: Architecture diagram to visualise how each GCP service relates to each other and to show the flow of data throughout system <br>
<b>File name</b>: `Architecture Diagram.pdf` <br>
<b>Location</b>: https://github.com/arjunS3887231/Eliiza/blob/main/Architecture%20Diagram.pdf <br>
<b>Requirements</b>: N/A <br>
<br>

#### EL-46 Apache Beam Pipeline Pseudocode [Jason]
<b>Description</b>: Pseudocode for the layout and structure of the Apache Beam pipeline <br>
<b>File name</b>: `pipeline.py` <br>
<b>Location</b>: https://github.com/arjunS3887231/Eliiza/blob/main/pipeline.py <br>
<b>Requirements</b>: N/A <br>
<br>
                 
#### El-63 Apache Beam Pipeline Prototype: Local Pipeline [Jason]
<b>Description</b>: Simple Apache Beam pipeline that is able to read a csv, carry out simple transforms, and write to a csv <br>
<b>File name</b>: `pipeline.py` <br>
<b>Location</b>: https://github.com/arjunS3887231/Eliiza/blob/main/pipeline.py <br>
<b>Requirements</b>: In the terminal run: `python3 pipeline.py` <br>
<br>

#### El-64 GCP Serverless Data Processing with Dataflow: Foundations [Jason]
<b>Description</b>: Completion badge for the Serverless Data Processing with Dataflow: Foundations course <br>
<b>File name</b>: `Serverless Data Processing with Dataflow - Foundations.png` <br>
<b>Location</b>:  https://github.com/arjunS3887231/Eliiza/blob/main/Data%20Engineering%20Course/Jason/Serverless%20Data%20Processing%20with%20Dataflow%20-%20Foundations.png <br>
<b>Requirements</b>: N/A <br>
<br>

#### El-65 GCP Serverless Data Processing with Dataflow: Developing Pipelines [Jason]
<b>Description</b>: Completion badge for the Serverless Data Processing with Dataflow: Developing Pipelines course <br>
<b>File name</b>: `Serverless Data Processing with Dataflow - Develop Pipelines.png` <br>
<b>Location</b>: https://github.com/arjunS3887231/Eliiza/blob/main/Data%20Engineering%20Course/Jason/Serverless%20Data%20Processing%20with%20Dataflow%20-%20Develop%20Pipelines.png <br>
<b>Requirements</b>: N/A <br>
<br>

#### El-66 GCP Serverless Data Processing with Dataflow: Operations [Jason]
<b>Description</b>: Completion badge for the Serverless Data Processing with Dataflow: Operations course <br>
<b>File name</b>: `Serverless Data Processing with Dataflow - Operations.png` <br>
<b>Location</b>:  https://github.com/arjunS3887231/Eliiza/blob/main/Data%20Engineering%20Course/Jason/Serverless%20Data%20Processing%20with%20Dataflow%20-%20Operations.png <br>
<b>Requirements</b>: N/A <br>
<be>

#### El-91 NYC Weather Data Feeder Program [Jason]
<b>Description</b>: Program to emulate a real time data stream that publishes messages to Pub/Sub on an hourly basis <br>
<b>File name</b>: `weather_emulator.py` <br>
<b>Location</b>:  https://github.com/arjunS3887231/Eliiza/blob/main/weather_emulator.py <br>
<b>Requirements</b>: In the terminal run: python3 weather_emulator.py

#### El-92 Error Checking/Logging in Pipeline [Jason]
<b>Description</b>: The pipeline is now able to check the format of the input messages and filter out any invalid messages <br>
<b>File name</b>: `pipeline.py` <br>
<b>Location</b>:  https://github.com/arjunS3887231/Eliiza/blob/main/pipeline.py <br>
<b>Requirements</b>: In the terminal run:
`python3 pipeline.py \
--project=${PROJECT_ID} \
--region=${REGION} \
--runner=${RUNNER} \
--staging_location=${PIPELINE_FOLDER}/staging \
--temp_location=${PIPLINE_FOLDER}/temp` <br>
<br>

#### El-96 Predicting Total Trips Per Hour [Jason]
<b>Description</b>: Training and evaluating different models to build a model that is able to predict the total number of trips per hour <br>
<b>File name</b>: `machine_learning.ipynb` <br>
<b>Location</b>:  https://github.com/arjunS3887231/Eliiza/blob/main/machine_learning.ipynb <br>
<b>Requirements</b>: N/A
<br>

#### EL-77 BigQuery Boiler PLate [Arjun]
<b>Description</b>: A BigQuery boiler plate for further development down the line. This contains streaming data aggregation made using GCP templates and NYC public Pub/Sub topic. <br>
<b>File name</b>: `arjun_mvp` <br>
<b>Location</b>: https://github.com/arjunS3887231/Eliiza/tree/main/Arjun_mvp <br>
<b>Requirements</b>: Gcloud auth credentials <br>
<br>

#### EL-79 Prototype DataStudio Boiler plate [Arjun]
<b>Description</b>: A visualization created using Data studio, with data aggregated from GCP dataflow template.<br>
<b>File name</b>: `arjun_mvp` <br>
<b>Location</b>: https://github.com/arjunS3887231/Eliiza/tree/main/Arjun_mvp <br>
<b>Requirements</b>: Gcloud auth credentials
<br>


#### EL-29 BigQuery - Developing queries [Sai]
<b>Description</b>:Provides data insights of NYC Taxi's total rides, revenue and total passengers for last 24 hours on a hourly basis.<br>
<b>File name</b>: `BigQuery-data-ML-Queries.sql` <br>
<b>Location</b>: https://github.com/arjunS3887231/Eliiza/blob/main/BigQuery-data-ML-Queries.sql<br>
<b>Requirements</b>: The Query can be only executed on Big query platform
<br>

#### EL-58 Feature Engineering and Training ML model-1 [Sai]
<b>Description</b>: This query is used to train the ML model. We also perform feature engineering before training the model<br>
<b>File name</b>: `BigQuery-data-ML-Queries.sql` <br>
<b>Location</b>: https://github.com/arjunS3887231/Eliiza/blob/main/BigQuery-data-ML-Queries.sql<br>
<b>Requirements</b>: The Query can be only executed on Big query platform
<br>

#### EL-57 Evaluating, and Implementing ML model-1 [Sai]
<b>Description</b>: We use this query to evalute the performance of the model. We use change parameters to predict the data.<br>
<b>File name</b>: `BigQuery-data-ML-Queries.sql` <br>
<b>Location</b>: https://github.com/arjunS3887231/Eliiza/blob/main/BigQuery-data-ML-Queries.sql<br>
<b>Requirements</b>: The Query can be only executed on Big query platform
<br>

#### EL-82 Mapping Streaming data features onto ML model. [Sai]
<b>Description</b>: We use this query to map streaming data on to the trained ML model.<br>
<b>File name</b>: `BigQuery-data-ML-Queries.sql` <br>
<b>Location</b>: https://github.com/arjunS3887231/Eliiza/blob/main/BigQuery-data-ML-Queries.sql<br>
<b>Requirements</b>: The Query can be only executed on Big query platform
<br>


#### EL-98 Feature Engineering and Training ML model-2 [Sai]
<b>Description</b>: This query is used to train the ML model. We also perform feature engineering before training the classification model<br>
<b>File name</b>: `BigQuery-data-ML-Queries.sql` <br>
<b>Location</b>: https://github.com/arjunS3887231/Eliiza/blob/main/BigQuery-data-ML-Queries.sql<br>
<b>Requirements</b>: The Query can be only executed on Big query platform
<br>

#### EL-99 Evaluating, and Implementing ML model-2 [Sai]
<b>Description</b>: We use this query to evalute the performance of the model. We use change parameters to predict the payment type from streaming data.<br>
<b>File name</b>: `BigQuery-data-ML-Queries.sql` <br>
<b>Location</b>: https://github.com/arjunS3887231/Eliiza/blob/main/BigQuery-data-ML-Queries.sql<br>
<b>Requirements</b>: The Query can be only executed on Big query platform
<br>
