#standardSQL-To find avg distance covered by a taxi in a hour.
SELECT
  EXTRACT(HOUR
  FROM
    pickup_datetime) hour,
  ROUND(AVG(trip_distance)) avg_dist
FROM
  `bigquery-public-data.new_york.tlc_yellow_trips_2015`
WHERE
  trip_distance > 0
  AND dropoff_datetime > pickup_datetime
GROUP BY
  1
 ;
  
#standardSQL_training and evaluating a ML model.After performing feature engineering

CREATE OR REPLACE MODEL taxi.taxifare_model_new
OPTIONS
  (model_type='linear_reg', labels=['total_fare']) AS
WITH params AS (
    SELECT
    1 AS TRAIN,
    2 AS EVAL
    ),
  daynames AS
    (SELECT ['Sun', 'Mon', 'Tues', 'Wed', 'Thurs', 'Fri', 'Sat'] AS daysofweek),
  taxitrips AS (
  SELECT
    (tolls_amount + fare_amount) AS total_fare,
    daysofweek[ORDINAL(EXTRACT(DAYOFWEEK FROM pickup_datetime))] AS dayofweek,
    EXTRACT(HOUR FROM pickup_datetime) AS hourofday,
    pickup_longitude AS pickuplon,
    pickup_latitude AS pickuplat,
    dropoff_longitude AS dropofflon,
    dropoff_latitude AS dropofflat,
    passenger_count AS passengers
  FROM
    `nyc-tlc.yellow.trips`, daynames, params
  WHERE
    trip_distance > 0
	AND fare_amount BETWEEN 6 and 200
    AND pickup_longitude > -75 #limiting of the distance the taxis travel out
    AND pickup_longitude < -73
    AND dropoff_longitude > -75
    AND dropoff_longitude < -73
    AND pickup_latitude > 40
    AND pickup_latitude < 42
    AND dropoff_latitude > 40
    AND dropoff_latitude < 42
    AND MOD(ABS(FARM_FINGERPRINT(CAST(pickup_datetime AS STRING))),1000) = params.TRAIN
  )
  SELECT *
  FROM taxitrips
 ;
 
#Evaluating the created training Model Query
SELECT
  SQRT(mean_squared_error) AS rmse
FROM
  ML.EVALUATE(MODEL taxi.taxifare_model_new,
  (
  WITH params AS (
    SELECT
    1 AS TRAIN,
    2 AS EVAL
    ),
  daynames AS
    (SELECT ['Sun', 'Mon', 'Tues', 'Wed', 'Thurs', 'Fri', 'Sat'] AS daysofweek),
  taxitrips AS (
  SELECT
    (tolls_amount + fare_amount) AS total_fare,
    daysofweek[ORDINAL(EXTRACT(DAYOFWEEK FROM pickup_datetime))] AS dayofweek,
    EXTRACT(HOUR FROM pickup_datetime) AS hourofday,
    pickup_longitude AS pickuplon,
    pickup_latitude AS pickuplat,
    dropoff_longitude AS dropofflon,
    dropoff_latitude AS dropofflat,
    passenger_count AS passengers
  FROM
    `nyc-tlc.yellow.trips`, daynames, params
  WHERE
    trip_distance > 0
	AND fare_amount BETWEEN 6 and 200
    AND pickup_longitude > -75 #limiting of the distance the taxis travel out
    AND pickup_longitude < -73
    AND dropoff_longitude > -75
    AND dropoff_longitude < -73
    AND pickup_latitude > 40
    AND pickup_latitude < 42
    AND dropoff_latitude > 40
    AND dropoff_latitude < 42
    AND MOD(ABS(FARM_FINGERPRINT(CAST(pickup_datetime AS STRING))),1000) = params.EVAL
  )
  SELECT *
  FROM taxitrips ))
 ;
 
 
#ML model to predict on the streaming data.

#standardSQL

SELECT
*
FROM
  ml.PREDICT(MODEL `taxi.taxifare_model_new`,
   (
  WITH params AS (
    SELECT
    1 AS TRAIN,
    2 AS EVAL
    ),
  daynames AS
    (SELECT ['Sun', 'Mon', 'Tues', 'Wed', 'Thurs', 'Fri', 'Sat'] AS daysofweek),
  taxitrips AS (
  SELECT
    (tolls_amount + fare_amount) AS total_fare,
    daysofweek[ORDINAL(EXTRACT(DAYOFWEEK FROM pickup_datetime))] AS dayofweek,
    EXTRACT(HOUR FROM pickup_datetime) AS hourofday,
    pickup_longitude AS pickuplon,
    pickup_latitude AS pickuplat,
    dropoff_longitude AS dropofflon,
    dropoff_latitude AS dropofflat,
    passenger_count AS passengers
  FROM
    `nyc-tlc.yellow.trips`, daynames, params
  WHERE
    trip_distance > 0
	AND fare_amount BETWEEN 6 and 200
    AND pickup_longitude > -75 #limiting of the distance the taxis travel out
    AND pickup_longitude < -73
    AND dropoff_longitude > -75
    AND dropoff_longitude < -73
    AND pickup_latitude > 40
    AND pickup_latitude < 42
    AND dropoff_latitude > 40
    AND dropoff_latitude < 42
    AND MOD(ABS(FARM_FINGERPRINT(CAST(pickup_datetime AS STRING))),1000) = params.EVAL
  )
  SELECT *
  FROM taxitrips ))
 ;
  
#Provides data insights of NYC Taxi's total rides, revenue and total passengers for last 24 hours on a hourly basis.
	   
WITH streaming_data AS (
SELECT
  timestamp,
  EXTRACT(hour from CAST (timestamp as timestamp)) AS hours,
  ride_id,
  latitude,
  longitude,
  meter_reading,
  ride_status,
  passenger_count
FROM
  `eliiza-de-student-project-2022.testing.realtime_test`
WHERE ride_status = 'dropoff' and DATE_DIFF(DATE(timestamp),CURRENT_DATE(), DAY)<=1
ORDER BY timestamp DESC
)
# calculate aggregations on stream for reporting:
SELECT
 ROW_NUMBER() OVER() AS dashboard_sort,
 hours,
 COUNT(DISTINCT ride_id) AS total_rides,
 SUM(meter_reading) AS total_revenue,
 SUM(passenger_count) AS total_passengers
FROM streaming_data 
GROUP BY hours 
	     
#Mapping SQL Query-streaming data
	    
#combining the streaming DATA TO convert it AS the nyc tlc dataset.
SELECT
  a.ride_id,
  a.point_idx AS pickup_point,
  a.latitude AS pickup_lat,
  a.longitude AS pickup_lon,
  a.timestamp AS pickup_time,
  b.point_idx AS dropoff_point,
  b.latitude AS dropoff_lat,
  b.longitude AS dropoff_lon,
  b.timestamp AS dropoff_time,
  b.passenger_count,
  b.meter_reading AS meter_reading,
  b.ride_status
FROM
  `eliiza-de-student-project-2022.testing.realtime_test` a,
  `eliiza-de-student-project-2022.testing.realtime_test` b
WHERE
  DATE(a.timestamp)= CURRENT_DATE('America/New_York')
  AND  DATE(b.timestamp)= CURRENT_DATE('America/New_York')
  AND a.ride_status='pickup'
  AND b.ride_status='dropoff'
  AND a.ride_id=b.ride_id ;

#Training the classification model
 CREATE OR REPLACE MODEL taxi.taxifare_model_pay
OPTIONS
  (model_type='logistic_reg', labels=['payment_type']) AS
WITH params AS (
    SELECT
    1 AS TRAIN,
    2 AS EVAL
    ),
  daynames AS
    (SELECT ['Sun', 'Mon', 'Tues', 'Wed', 'Thurs', 'Fri', 'Sat'] AS daysofweek),
  taxitrips AS (
  SELECT
    payment_type AS payment_type,
    daysofweek[ORDINAL(EXTRACT(DAYOFWEEK FROM pickup_datetime))] AS dayofweek,
    EXTRACT(HOUR FROM pickup_datetime) AS hourofday,
    pickup_longitude AS pickuplon,
    pickup_latitude AS pickuplat,
    dropoff_longitude AS dropofflon,
    dropoff_latitude AS dropofflat,
    passenger_count AS passengers
  FROM
    `nyc-tlc.yellow.trips`, daynames, params
  WHERE
    trip_distance > 0
	AND fare_amount BETWEEN 6 and 200
    AND pickup_longitude > -75 #limiting of the distance the taxis travel out
    AND pickup_longitude < -73
    AND dropoff_longitude > -75
    AND dropoff_longitude < -73
    AND pickup_latitude > 40
    AND pickup_latitude < 42
    AND dropoff_latitude > 40
    AND dropoff_latitude < 42
    AND MOD(ABS(FARM_FINGERPRINT(CAST(pickup_datetime AS STRING))),1000) = params.TRAIN
  )
  SELECT *
  FROM taxitrips
 ;

#Implementing the model

SELECT
  *
FROM
  ml.PREDICT(MODEL `eliiza-de-student-project-2022.taxi.taxifare_model_pay`,
    (
    WITH
      params AS (
      SELECT
        1 AS TRAIN,
        2 AS EVAL ),
      daynames AS (
      SELECT
        ['Sun',
        'Mon',
        'Tues',
        'Wed',
        'Thurs',
        'Fri',
        'Sat'] AS daysofweek),
      taxitrips AS (
      SELECT
        daysofweek[ORDINAL(EXTRACT(DAYOFWEEK
          FROM
            DATE(pickup_time)))] AS dayofweek,
        EXTRACT(HOUR
        FROM
          pickup_time) AS hourofday,
        pickup_lon AS pickuplon,
        pickup_lat AS pickuplat,
        dropoff_lon AS dropofflon,
        dropoff_lat AS dropofflat,
        passenger_count AS passengers
      FROM
        eliiza-de-student-project-2022.taxi.stream_12,
        daynames,
        params
      WHERE
        pickup_lon > -75 #limiting OF the distance the taxis travel OUT
        AND pickup_lon < -73
        AND dropoff_lon > -75
        AND dropoff_lon < -73
        AND pickup_lat > 40
        AND pickup_lat < 42
        AND dropoff_lat > 40
        AND dropoff_lat < 42 )
    SELECT
      *
    FROM
      taxitrips )) ;


